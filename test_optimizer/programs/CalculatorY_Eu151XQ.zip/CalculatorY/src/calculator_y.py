import math

class CalculatorLogic:
    def __init__(self):
        self.expression = ""

    def add_to_expression(self, value):
        self.expression += str(value)

    def clear(self):
        self.expression = ""

    def evaluate(self):
        try:
            # Basic safe parser
            expr = self.expression.replace("x", "*").replace("÷", "/")
            result = eval(expr, {"__builtins__": {}}, math.__dict__)
            return str(round(result, 3))
        except Exception as e:
            return "Error"

    # Optional: method to directly handle pow/root if needed
    def calculate_custom(self, op, num1, num2=None):
        try:
            num1 = float(num1)
            if op in ["+", "-", "x", "/"]:
                num2 = float(num2)

            if op == "+":
                return str(num1 + num2)
            elif op == "-":
                return str(num1 - num2)
            elif op == "x":
                return str(num1 * num2)
            elif op == "/":
                return "{:.3f}".format(num1 / num2)
            elif op == "root":
                num2 = float(num2)
                return "{:.2f}".format(math.pow(num1, 1 / num2))
            elif op == "pow":
                num2 = float(num2)
                return "{:.2f}".format(math.pow(num1, num2))
            else:
                return "Invalid op"
        except Exception as e:
            return "Error: " + str(e)
