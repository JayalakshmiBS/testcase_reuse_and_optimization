import math

class CalculatorLogic:
    def __init__(self):
        self.current_expression = ""

    def add_to_expression(self, value):
        self.current_expression += str(value)

    def append_operator(self, operator):
        self.current_expression += operator

    def clear(self):
        self.current_expression = ""

    def evaluate(self):
        try:
            expr = self.current_expression.replace("x", "*").replace("÷", "/")
            result = eval(expr, {"__builtins__": {}}, math.__dict__)
            if result > 100:
                self.current_expression = "Too Big"
            elif result < 0:
                self.current_expression = "Negative"
            else:
                self.current_expression = str(round(result, 3))
        except ZeroDivisionError:
            self.current_expression = "Division by Zero"
        except:
            self.current_expression = "Error"


    def sqrt(self):
            try:
                value = eval(self.current_expression, {"__builtins__": {}}, math.__dict__)
                self.current_expression = str(round(math.sqrt(value), 3))
            except:
                self.current_expression = "Error"

    def square(self):
            try:
                value = eval(self.current_expression, {"__builtins__": {}}, math.__dict__)
                self.current_expression = str(round(value ** 2, 3))
            except:
                self.current_expression = "Error"

    def get_expression(self):
            return self.current_expression
