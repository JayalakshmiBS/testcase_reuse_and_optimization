# calculator_logic.py

import math

def calculate(op, num1, num2=None):
    try:
        num1 = float(num1)
        if op in ["+", "-", "x", "/"]:
            num2 = float(num2)

        if op == "+":
            return str(num1 + num2)
        elif op == "-":
            return str(num1 - num2)
        elif op == "x":
            return str(num1 * num2)
        elif op == "/":
            return "{:.3f}".format(num1 / num2)
        elif op == "root":
            # num2 = root degree (e.g., 2 for square root)
            num2 = float(num2)
            return "{:.2f}".format(math.pow(num1, 1 / num2))
        elif op == "pow":
            num2 = float(num2)
            return "{:.2f}".format(math.pow(num1, num2))
        else:
            return "Invalid op"
    except Exception as e:
        return "Error: " + str(e)
