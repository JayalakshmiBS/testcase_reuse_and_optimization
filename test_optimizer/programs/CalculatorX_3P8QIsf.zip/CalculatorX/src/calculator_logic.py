from math import *

# Conversion constants
DEG = pi / 180
RAD = 1

class CalculatorLogic:
    def __init__(self):
        self.expression = ""
        self.memory = ""
        self.answer = ""
        self.convert_constant = RAD
        self.inverse_convert_constant = RAD

    def set_mode(self, mode):
        if mode == 'DEG':
            self.convert_constant = DEG
            self.inverse_convert_constant = 1 / DEG
        else:
            self.convert_constant = RAD
            self.inverse_convert_constant = RAD

    def append(self, value):
        self.expression += str(value)
        return self.expression

    def clear(self):
        self.expression = ""
        return self.expression

    def delete_last(self):
        self.expression = self.expression[:-1]
        return self.expression

    def evaluate(self):
        try:
            result = str(eval(self.expression, {"__builtins__": None}, self.safe_functions()))
            self.answer = result
            self.expression = result
            return result
        except Exception as e:
            return "Error"

    def memory_add(self):
        self.memory = self.expression

    def memory_recall(self):
        self.expression += self.memory
        return self.expression

    def memory_clear(self):
        self.memory = ""

    def get_expression(self):
        return self.expression

    def safe_functions(self):
        return {
            "sin": lambda x: sin(x * self.convert_constant),
            "cos": lambda x: cos(x * self.convert_constant),
            "tan": lambda x: tan(x * self.convert_constant),
            "asin": lambda x: self.inverse_convert_constant * asin(x),
            "acos": lambda x: self.inverse_convert_constant * acos(x),
            "atan": lambda x: self.inverse_convert_constant * atan(x),
            "sqrt": sqrt,
            "log": log10,
            "ln": log,
            "exp": exp,
            "pi": pi,
            "e": e,
            "abs": abs,
            "factorial": factorial
        }
