# scientific_calculator_logic.py
import math

class ScientificCalculatorLogic:
    def __init__(self):
        self.expression = ""

    def button_click(self, char):
        self.expression += str(char)
        return self.expression

    def button_clear_all(self):
        self.expression = ""
        return self.expression

    def button_delete(self):
        self.expression = self.expression[:-1]
        return self.expression

    def factorial(self):
        try:
            n = int(self.expression)
            if n < 0: return "Error"
            if n == 0 or n == 1:
                self.expression = "1"
                return "1"
            else:
                res = 1
                for i in range(1, n + 1):
                    res *= i
                self.expression = str(res)
                return str(res)
        except:
            return "Error"

    def trig_sin(self):
        self.expression = str(math.sin(math.radians(int(self.expression))))
        return self.expression

    def trig_cos(self):
        self.expression = str(math.cos(math.radians(int(self.expression))))
        return self.expression

    def square_root(self):
        self.expression = str(math.sqrt(int(self.expression)))
        return self.expression

    def button_equal(self):
        try:
            # Replace special characters for eval
            temp_expr = self.expression.replace('^', '**').replace('π', str(math.pi))
            result = str(eval(temp_expr))
            self.expression = result
            return result
        except:
            return "Error"