# scientific_ui.py
import tkinter as tk
from tkinter import messagebox
from calculator_s import ScientificCalculator

calc = ScientificCalculator()

def evaluate(operation):
    try:
        x = entry1.get()
        y = entry2.get()

        if operation in ['add', 'subtract', 'multiply', 'divide', 'power']:
            result = getattr(calc, operation)(x, y)
        elif operation in ['factorial', 'square', 'cube', 'sqrt', 'inverse', 'percent',
                           'sin', 'cos', 'tan', 'cot', 'log10']:
            result = getattr(calc, operation)(x)
        else:
            result = "Unknown operation"

        result_label.config(text=f"Result: {result}")
    except Exception as e:
        messagebox.showerror("Error", str(e))

root = tk.Tk()
root.title("Scientific Calculator")
root.geometry("400x550")

tk.Label(root, text="Input 1").pack()
entry1 = tk.Entry(root)
entry1.pack()

tk.Label(root, text="Input 2 (for binary operations)").pack()
entry2 = tk.Entry(root)
entry2.pack()

btn_frame = tk.Frame(root)
btn_frame.pack(pady=10)

buttons = [
    ('+', 'add'), ('-', 'subtract'), ('×', 'multiply'), ('÷', 'divide'),
    ('xʸ', 'power'), ('x²', 'square'), ('x³', 'cube'), ('√x', 'sqrt'),
    ('1/x', 'inverse'), ('sin', 'sin'), ('cos', 'cos'), ('tan', 'tan'),
    ('cot', 'cot'), ('log₁₀', 'log10'), ('x!', 'factorial'), ('%', 'percent'),
]

for (text, func) in buttons:
    b = tk.Button(btn_frame, text=text, width=10,
                  command=lambda f=func: evaluate(f))
    b.pack(pady=3)

result_label = tk.Label(root, text="Result: ", font=('Arial', 14))
result_label.pack(pady=10)

root.mainloop()
