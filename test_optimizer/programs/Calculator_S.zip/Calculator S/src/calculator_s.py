import tkinter as tk
from math import *

class ScientificCalculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Scientific Calculator")
        self.root.geometry("420x600")
        self.root.resizable(False, False)

        self.expression = ""
        self.input_text = tk.StringVar()

        self.input_frame = tk.Frame(self.root, width=400, height=50, bd=0)
        self.input_frame.pack(side=tk.TOP)

        self.input_field = tk.Entry(
            self.input_frame, font=('arial', 18, 'bold'),
            textvariable=self.input_text, width=50, bg="#eee", bd=0, justify=tk.RIGHT
        )
        self.input_field.grid(row=0, column=0)
        self.input_field.pack(ipady=10)

        self.buttons_frame = tk.Frame(self.root, bg="grey")
        self.buttons_frame.pack()

        self.create_buttons()

    def create_buttons(self):
        buttons = [
            ['C', '(', ')', '⌫'],
            ['7', '8', '9', '/'],
            ['4', '5', '6', '*'],
            ['1', '2', '3', '-'],
            ['0', '.', '%', '+'],
            ['sin', 'cos', 'tan', '√'],
            ['x²', 'x³', 'xⁿ', '1/x'],
            ['abs', 'log', 'x!', '=']
        ]

        for i, row in enumerate(buttons):
            for j, button in enumerate(row):
                b = tk.Button(
                    self.buttons_frame, text=button, width=8, height=2,
                    font=('arial', 14), bd=1, bg="#f2f2f2", fg="black",
                    command=lambda b=button: self.on_button_click(b)
                )
                b.grid(row=i, column=j, padx=1, pady=1)

    def on_button_click(self, char):
        if char == "C":
            self.expression = ""
            self.input_text.set("")
        elif char == "=":
            try:
                result = self.evaluate_expression(self.expression)
                self.input_text.set(result)
                self.expression = str(result)
            except Exception:
                self.input_text.set("Error")
                self.expression = ""
        elif char == "⌫":
            self.expression = self.expression[:-1]
            self.input_text.set(self.expression)
        elif char == "sin":
            self.expression += "sin(radians("
            self.input_text.set(self.expression)
        elif char == "cos":
            self.expression += "cos(radians("
            self.input_text.set(self.expression)
        elif char == "tan":
            self.expression += "tan(radians("
            self.input_text.set(self.expression)
        elif char == "log":
            self.expression += "log10("
            self.input_text.set(self.expression)
        elif char == "√":
            self.expression += "sqrt("
            self.input_text.set(self.expression)
        elif char == "x²":
            self.expression += "**2"
            self.input_text.set(self.expression)
        elif char == "x³":
            self.expression += "**3"
            self.input_text.set(self.expression)
        elif char == "xⁿ":
            self.expression += "**"
            self.input_text.set(self.expression)
        elif char == "1/x":
            self.expression = f"1/({self.expression})"
            self.input_text.set(self.expression)
        elif char == "abs":
            self.expression += "abs("
            self.input_text.set(self.expression)
        elif char == "x!":
            self.expression += "factorial("
            self.input_text.set(self.expression)
        else:
            self.expression += str(char)
            self.input_text.set(self.expression)

    def evaluate_expression(self, expression):
        # Evaluate the final expression safely
        return eval(expression)

if __name__ == "__main__":
    root = tk.Tk()
    app = ScientificCalculator(root)
    root.mainloop()
