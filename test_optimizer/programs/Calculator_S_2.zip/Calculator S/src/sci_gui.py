import tkinter as tk
from tkinter import messagebox
from logic import CalculatorLogic  # Assumes logic is in calculator_logic.py

class ScientificCalculatorUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Scientific Calculator")
        self.root.geometry("480x600")
        self.root.resizable(False, False)

        self.expression = ""
        self.logic = CalculatorLogic()

        self.input_text = tk.StringVar()
        self.create_widgets()

    def create_widgets(self):
        input_frame = tk.Frame(self.root, width=400, height=50, bd=0)
        input_frame.pack(side=tk.TOP)

        input_field = tk.Entry(input_frame, font=('arial', 18), textvariable=self.input_text, width=50, bd=10, insertwidth=2, bg="powder blue", justify='right')
        input_field.grid(row=0, column=0)
        input_field.pack(ipady=10)

        btns_frame = tk.Frame(self.root, bg="grey")
        btns_frame.pack()

        buttons = [
            ['7', '8', '9', '/', '√', 'x²'],
            ['4', '5', '6', '*', '(', ')'],
            ['1', '2', '3', '-', 'sin', 'cos'],
            ['0', '.', '=', '+', 'tan', 'ln'],
            ['π', 'e', '^', 'log', 'x!', 'C']
        ]

        for i, row in enumerate(buttons):
            for j, btn in enumerate(row):
                b = tk.Button(btns_frame, text=btn, width=7, height=2, font=('Arial', 14),
                              command=lambda b=btn: self.button_click(b))
                b.grid(row=i, column=j, padx=2, pady=2)

    def button_click(self, button):
        if button == "=":
            try:
                result = self.logic.evaluate_expression(self.expression)
                self.input_text.set(result)
                self.expression = str(result)
            except Exception as e:
                messagebox.showerror("Error", f"Invalid expression\n{e}")
                self.expression = ""
                self.input_text.set("")
        elif button == "C":
            self.expression = ""
            self.input_text.set("")
        else:
            self.expression += self.logic.convert_button_input(button)
            self.input_text.set(self.expression)

if __name__ == "__main__":
    root = tk.Tk()
    app = ScientificCalculatorUI(root)
    root.mainloop()
