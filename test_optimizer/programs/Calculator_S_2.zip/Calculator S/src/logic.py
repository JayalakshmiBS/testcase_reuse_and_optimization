from math import *

class CalculatorLogic:
    def __init__(self):
        self.constants = {
            'π': str(pi),
            'e': str(e)
        }

    def convert_button_input(self, btn):
        if btn in self.constants:
            return self.constants[btn]
        if btn == '^':
            return '**'
        if btn == '√':
            return 'sqrt('
        if btn == 'x²':
            return '**2'
        if btn == 'x!':
            return 'factorial('
        if btn in ['sin', 'cos', 'tan', 'log', 'ln']:
            return f'{btn}('
        return btn

    def evaluate_expression(self, expr):
        expr = expr.replace('ln(', 'log(')  # natural log (ln) is log base e
        return eval(expr)

# Example (for test):
if __name__ == "__main__":
    calc = CalculatorLogic()
    print(calc.evaluate_expression("sin(pi/2) + log(100)"))
