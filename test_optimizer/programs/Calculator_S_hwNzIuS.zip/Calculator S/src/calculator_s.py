# calculator_logic.py

import math

def factorial(n):
    if n == 0 or n == 1:
        return 1
    return n * factorial(n - 1)

def calculate_expression(expr: str) -> str:
    try:
        result = str(eval(expr, safe_namespace()))
        return result
    except Exception:
        return "ERROR"

def safe_namespace():
    return {
        'abs': abs,
        'round': round,
        'sin': lambda x: math.sin(math.radians(x)),
        'cos': lambda x: math.cos(math.radians(x)),
        'tan': lambda x: math.tan(math.radians(x)),
        'cot': lambda x: 1 / math.tan(math.radians(x)),
        'log': math.log10,
        'ln': math.log,
        'sqrt': math.sqrt,
        'e': math.exp(1),
        'pi': math.pi,
        'fact': factorial,
    }

def apply_function(func_name, value):
    try:
        return str(safe_namespace()[func_name](float(value)))
    except:
        return "ERROR"
